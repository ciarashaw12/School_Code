module.exports = {
    "extends": "google",
    "parserOptions": {
        "ecmaVersion": 6
    },
    "rules": {
        "no-const-assign": 2,
        "linebreak-style": 0,
        "valid-jsdoc": 0,
        "require-jsdoc": 0,
        "quotes": 0,
        "max-len": 0
    }
};